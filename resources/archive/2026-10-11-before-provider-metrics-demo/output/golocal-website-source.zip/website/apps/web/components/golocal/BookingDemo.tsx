"use client";

import Image from "next/image";
import { useEffect, useRef, useState } from "react";

const providers = [
  { name: "Oak Plumbing", initials: "OP", fee: 79, time: "9–11 am", detail: "Earliest morning visit" },
  { name: "Canyon Plumbing", initials: "CP", fee: 95, time: "10 am–12 pm", detail: "Another morning option" },
  { name: "Jordan Home Plumbing", initials: "JP", fee: 69, time: "1–3 pm", detail: "Lower visit fee, later arrival" },
];
const stages = ["Scope", "Compare", "Approve", "Booked"];
const beats = [
  { kind: "request", stage: 0, delay: 0 },
  { kind: "question", stage: 0, delay: 1800 },
  { kind: "answer", stage: 0, delay: 3000 },
  { kind: "diagnosis", stage: 0, delay: 4000 },
  { kind: "search", stage: 1, delay: 6500 },
  { kind: "options", stage: 1, delay: 2400 },
  { kind: "choice", stage: 1, delay: 6500 },
  { kind: "approval", stage: 2, delay: 2200 },
  { kind: "approve", stage: 2, delay: 6500 },
  { kind: "booking", stage: 3, delay: 1400 },
  { kind: "confirmed", stage: 3, delay: 2600 },
  { kind: "done", stage: 3, delay: 2200 },
] as const;

type BeatKind = (typeof beats)[number]["kind"];
const countThrough = (kind: BeatKind) => beats.findIndex(beat => beat.kind === kind) + 1;
const stageStarts = stages.map((_, stage) => beats.findIndex(beat => beat.stage === stage) + 1);
const userBeats = new Set<BeatKind>(["request", "answer", "choice", "approve"]);

export default function BookingDemo() {
  const [count, setCount] = useState(1);
  const [selected, setSelected] = useState(0);
  const [mode, setMode] = useState<"auto" | "play" | "pause">("auto");
  const [inView, setInView] = useState(false);
  const [pageVisible, setPageVisible] = useState(true);
  const [reducedMotion, setReducedMotion] = useState(true);
  const root = useRef<HTMLDivElement>(null);
  const transcript = useRef<HTMLDivElement>(null);
  const complete = count === beats.length;
  const playing = !complete && inView && pageVisible && mode !== "pause" && (mode === "play" || !reducedMotion);
  const stage = beats[count - 1].stage;
  const provider = providers[selected];
  const latestUserBeat = beats.slice(0, count).filter(beat => userBeats.has(beat.kind)).at(-1)?.kind;

  useEffect(() => {
    const media = window.matchMedia("(prefers-reduced-motion: reduce)");
    const motion = () => setReducedMotion(media.matches);
    const visibility = () => setPageVisible(document.visibilityState === "visible");
    motion();
    visibility();
    media.addEventListener("change", motion);
    document.addEventListener("visibilitychange", visibility);
    const observer = new IntersectionObserver(([entry]) => setInView(entry.isIntersecting && entry.intersectionRatio >= 0.35), { threshold: 0.35 });
    if (root.current) observer.observe(root.current);
    return () => {
      observer.disconnect();
      media.removeEventListener("change", motion);
      document.removeEventListener("visibilitychange", visibility);
    };
  }, []);

  useEffect(() => {
    if (!playing) return;
    const timer = window.setTimeout(() => setCount(value => Math.min(value + 1, beats.length)), beats[count].delay);
    return () => window.clearTimeout(timer);
  }, [count, playing]);

  useEffect(() => {
    const panel = transcript.current;
    if (panel) panel.scrollTo({ top: panel.scrollHeight, behavior: reducedMotion ? "instant" : "smooth" });
  }, [count, reducedMotion]);

  function replay() {
    setCount(1);
    setSelected(0);
    setMode("play");
  }

  function choose(index: number) {
    setSelected(index);
    setCount(countThrough("choice"));
    setMode("play");
  }

  function renderBeat(kind: BeatKind) {
    switch (kind) {
      case "request": return <p>Can you book a plumber for my leaking kitchen tap in Salt Lake City tomorrow morning?</p>;
      case "question": return <p>Of course. Send me a photo of the tap showing where it’s leaking.</p>;
      case "answer": return <><figure className="gl-demo-photo"><Image src="/demo/dripping-kitchen-tap.png" alt="Example photo of a chrome single-lever kitchen tap with a droplet at the spout over a stainless steel sink" width={1536} height={1024} sizes="(max-width: 800px) 260px, 300px" /><figcaption>Kitchen tap · Example photo</figcaption></figure><p>Here you go. It keeps dripping even with the handle turned off.</p></>;
      case "diagnosis": return <><p>I can see the drip at the end of the spout. This looks like a single-lever tap; the cartridge inside may not be sealing properly.</p><p className="gl-demo-diagnosis-followup">I’ll raise a service request for a dripping kitchen tap and attach your photo. The plumber can confirm the cause on the visit.</p><div className="gl-demo-request-tag"><span aria-hidden="true">✓</span> Service request prepared · Photo attached</div></>;
      case "search": return <div className="gl-demo-activity"><span aria-hidden="true">⌕</span><div><strong>Finding the right local visit</strong><span>Service area → availability → visit pricing</span></div><span className="gl-demo-activity-check" aria-hidden="true">✓</span></div>;
      case "options": return <><p>I found three options for a leaking-tap diagnostic visit. Oak has the earliest morning window.</p><div className="gl-demo-options">{providers.map((option, index) => <button key={option.name} className={`gl-demo-option ${selected === index ? "is-selected" : ""}`} disabled={count > countThrough("options")} onClick={() => choose(index)} aria-label={`Choose ${option.name}, $${option.fee} visit fee, tomorrow ${option.time}`}><span className="gl-demo-provider-mark" aria-hidden="true">{option.initials}</span><span className="gl-demo-provider-info"><strong>{option.name}</strong><span>Tomorrow · {option.time}</span><small>{option.detail}</small></span><span className="gl-demo-price"><strong>${option.fee}</strong><small>visit fee</small></span><span aria-hidden="true">{selected === index ? "✓" : "↗"}</span></button>)}</div>{count === countThrough("options") && <small className="gl-demo-hint">Try choosing a provider, or watch the demo continue.</small>}</>;
      case "choice": return <p>{provider.name} works. Let’s book the {provider.time} visit.</p>;
      case "approval": return <><p>Here’s everything before I book. The visit fee covers diagnosis; any repair quote needs your approval.</p><div className="gl-demo-review"><div><span>YOUR VISIT</span><strong>{provider.name}</strong></div><dl><div><dt>When</dt><dd>Tomorrow, {provider.time}</dd></div><div><dt>Where</dt><dd>Your Salt Lake City home</dd></div><div><dt>Visit fee</dt><dd>${provider.fee}</dd></div></dl><button className="gl-demo-approve" disabled={count > countThrough("approval")} onClick={() => { setCount(countThrough("approve")); setMode("play"); }}>{count > countThrough("approval") ? "Approved in demo ✓" : "Approve example booking →"}</button></div></>;
      case "approve": return <p>Yes, go ahead. Thank you!</p>;
      case "booking": return <div className="gl-demo-activity"><span aria-hidden="true">↗</span><div><strong>Sending your approved booking</strong><span>GoLocal → {provider.name}’s scheduling system</span></div><span className="gl-demo-activity-check" aria-hidden="true">✓</span></div>;
      case "confirmed": return <div className="gl-demo-receipt"><span className="gl-demo-receipt-icon" aria-hidden="true">✓</span><span className="gl-mono">EXAMPLE BOOKING CONFIRMED</span><h3>You’re all set.</h3><p>{provider.name} · Tomorrow, {provider.time}</p><div><span>Leaking-tap diagnostic visit</span><strong>${provider.fee}</strong></div><small>Confirmation GL-1042 · Example details</small></div>;
      case "done": return <p>All booked. I’ve got the details right here in our chat whenever you need them. One less thing on your list.</p>;
    }
  }

  return <div ref={root} className="gl-demo gl-conversation-demo gl-imessage">
    <div className="gl-imessage-status" aria-hidden="true"><span>9:41</span><span className="gl-imessage-island" /><span>▮▮▮ <svg width="16" height="12" viewBox="0 0 20 14" fill="none"><path d="M2 5Q10 -1 18 5M5 8Q10 4 15 8M8 11Q10 9 12 11" stroke="currentColor" strokeWidth="2" strokeLinecap="round" /></svg><span className="gl-imessage-battery" /></span></div>
    <div className="gl-imessage-contact"><span className="gl-imessage-back" aria-hidden="true">‹</span><div className="gl-imessage-contact-person"><span className="gl-imessage-avatar"><Image src="/agents/openclaw.jpeg" alt="OpenClaw" width={377} height={133} /></span><strong>Your local agent <span aria-hidden="true">›</span></strong><small>OpenClaw · iMessage demo</small></div><span className="gl-imessage-demo-label">DEMO</span></div>
    <div className="gl-demo-steps" aria-label="Demo chapters">{stages.map((label, index) => <button key={label} onClick={() => { setCount(stageStarts[index]); setMode("pause"); }} aria-current={stage === index ? "step" : undefined}><span>{index < stage ? "✓" : index + 1}</span>{label}</button>)}</div>
    <div className="gl-demo-transcript" ref={transcript} role="log" aria-label="Simulated booking conversation" aria-live="polite" aria-relevant="additions" tabIndex={0} onWheel={() => setMode("pause")} onTouchMove={() => setMode("pause")} onKeyDown={event => { if (["ArrowUp", "ArrowDown", "PageUp", "PageDown", "Home", "End"].includes(event.key)) setMode("pause"); }}>
      <div className="gl-demo-conversation-date">iMessage · Today 9:41 AM</div>
      {beats.slice(0, count).map(({ kind }) => {
        const isUser = userBeats.has(kind);
        const isActivity = kind === "search" || kind === "booking";
        return <div key={kind} className={`gl-demo-message ${isUser ? "gl-demo-message-user" : "gl-demo-message-agent"} ${isActivity ? "gl-demo-message-system" : ""}`}>
          {!isActivity && <span className="gl-demo-speaker">{isUser ? "You" : "Your local agent"}</span>}
          <div className="gl-demo-bubble">{renderBeat(kind)}</div>
          {isUser && kind === latestUserBeat && <span className="gl-imessage-delivered">Delivered</span>}
        </div>;
      })}
      {playing && <div className="gl-demo-typing" aria-hidden="true"><span /><span /><span /><small>{userBeats.has(beats[count].kind) ? "Your reply" : "Your agent"}</small></div>}
    </div>
    <div className="gl-imessage-composer" aria-hidden="true"><span className="gl-imessage-plus">+</span><span className="gl-imessage-input">iMessage<span>↑</span></span></div>
    <div className="gl-demo-playback"><span className="gl-demo-playback-status" role="status">{complete ? "A request. A conversation. A booking." : playing ? "Watching the booking unfold" : "Explore at your own pace"}</span><div><button onClick={() => complete ? replay() : setMode(playing ? "pause" : "play")} aria-label={complete ? "Replay demo" : playing ? "Pause demo" : "Play demo"}>{complete ? "↻ Replay" : playing ? "Ⅱ Pause" : "▶ Play"}</button>{!complete && <button onClick={() => { setCount(value => Math.min(value + 1, beats.length)); setMode("pause"); }} aria-label="Next message">Next <span aria-hidden="true">→</span></button>}</div></div>
    <div className="gl-demo-progress" aria-hidden="true"><span style={{ width: `${count / beats.length * 100}%` }} /></div>
    <div className="gl-demo-disclosure">Illustrative iMessage experience. Agent integration in development. Fictional businesses and prices; no real booking is made.</div>
  </div>;
}
