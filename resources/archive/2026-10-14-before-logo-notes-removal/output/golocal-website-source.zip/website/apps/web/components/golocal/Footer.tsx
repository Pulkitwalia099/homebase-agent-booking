import Link from "next/link";
import Logo from "./Logo";
export default function Footer() {
  return <footer className="gl-footer"><div className="gl-container"><div className="gl-footer-top"><div><Logo light /><p>Local services, booked by your personal agent.</p></div><div className="gl-footer-links"><Link href="/pilot">Customer & supplier pilot</Link><Link href="/connectors">Connect your agent</Link><Link href="/businesses">Businesses</Link><Link href="/agents">Agent partners</Link><Link href="/partners">Channel partners</Link><a href="mailto:pulkitwalia099@gmail.com">Contact us ↗</a></div></div><div className="gl-footer-bottom"><span>© {new Date().getFullYear()} GoLocal</span><span>Connecting personal agents to the local world.</span><Link href="/privacy">Privacy</Link></div></div></footer>;
}
